<form action="index.php" method="post" role="search">
    <input type="text" value="" name="searchword" placeholder="<?php echo JText::_('search...'); ?>" />
    <input type="hidden" name="task"   value="search" />
    <input type="hidden" name="option" value="com_search" />
</form>